var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://51.140.140.65:27017/mydb";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  console.log("Database created!");
  db.close();
});