const express = require('express')
const Joi = require('@hapi/joi')
const { getpostman, getcustomers } = require('./db')

const router = express.Router()

var nestedSchema = Joi.object().keys({
    addresses: Joi.string()
});

const itemSchema = Joi.object().keys({
  postman_name: Joi.string(),
  postman_age: Joi.number(),
  postman_adresses: nestedSchema,
  postman_number: Joi.string(),
  postman_state: Joi.string(),
  postman_vehicle: Joi.string()
})

const itemSchema1 = Joi.object().keys({
  name: Joi.string(),
  age: Joi.number(),
  addresses: nestedSchema
 })

router.get('/postman', (req, res) => {
  getpostman()
    .then((postman) => {
      postman = postman.map((item) => ({
        postman_name: item.name,
        postman_age: item.age,
        postman_adresses: item.adresses,
        postman_number: item.number,
        postman_state: item.state,
        postman_vehicle: item.Bike        
       
      }))
      res.json(postman)
    })
    .catch((err) => {
      console.log(err)
      res.status(500).end()
    })
})

router.get('/customers', (req, res) => {
  getcustomers()
    .then((customers) => {
      customers = customers.map((item) => ({
        name: item.name,
        age: item.age,
        addresses: item.addresses
            
      }))
      res.json(customers)
    })
    .catch((err) => {
      console.log(err)
      res.status(500).end()
    })
})

module.exports = router