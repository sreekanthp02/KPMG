var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://51.140.140.65:27017/";
var dbo

const init = () =>

  MongoClient.connect(url, { useNewUrlParser: true }).then((client) => {
  dbo = client.db("mydb");
});

const getpostman = () => {
  
   var collection = dbo.collection("postman")
   return collection.find({}).toArray()
}

const getcustomers = () => {
  
   var collection = dbo.collection("customers")
   return collection.find({}).toArray()
}
module.exports = { init, getpostman, getcustomers }