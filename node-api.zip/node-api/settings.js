﻿exports.dbConfig = {
    user: "postman",
    password: "sqlserver123$",
    server: "postman.database.windows.net", 
    database: "postman",
    port: 1433
};

exports.webPort = 8000;

exports.httpMsgsFormat = "JSON";