{
  "name": "SampleREST",
  "version": "0.0.0",
  "description": "SampleREST",
  "main": "app.js",
  "author": {
    "name": "Personal",
    "email": ""
  },
  "dependencies": {
    "mssql": "^2.1.7"
  }
}