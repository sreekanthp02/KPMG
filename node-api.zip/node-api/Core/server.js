var http = require("http");
var httpMsgs = require("./httpMsgs");
var settings = require("../settings");
var postman = require("../controllers/postman");

http.createServer(function (req, resp) {
    switch (req.method) {
        case "GET":
            if (req.url === "/") {
                httpMsgs.showHome(req, resp);
            }
            else if (req.url === "/postmans") {
                postman.getList(req, resp);
            }
            else {
                var postmanAtt = "PM[0-9]+";
                var patt = new RegExp("/postmans/" + postmanAtt);
                if (patt.test(req.url)) {
                    patt = new RegExp(postmanAtt);
                    var postman_number = patt.exec(req.url);
                    postman.get(req, resp, postman_number);
                }
                else {
                    httpMsgs.show404(req, resp);
                }                
            }
            break;
               
        default:
            httpMsgs.show405(req, resp);
            break;
    }
}).listen(settings.webPort, function () {
    console.log("Started listening at: " + settings.webPort);
});